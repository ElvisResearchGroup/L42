define("ace/mode/matching_brace_outdent",["require","exports","module","ace/range"], function(require, exports, module) {
"use strict";


var MatchingBraceOutdent = function() {};

(function() {
  this.checkOutdent = function(line, input) {
    if (! /^\s+$/.test(line)){return false;}
    return /^\s*\}/.test(input);
    };
  this.autoOutdent = function(doc, row) {
    var line = doc.getLine(row);
    var match = line.match(/^(\s*\})/);
    if (!match){return 0;}
    var column = match[1].length;
    var openBracePos = doc.findMatchingBracket({row: row, column: column});
    if (!openBracePos || openBracePos.row == row) return 0;
    var indent = this.$getIndent(doc.getLine(openBracePos.row));
    doc.replace(new Range(row, 0, row, column-1), indent);
    };
    this.$getIndent = function(line) {return line.match(/^\s*/)[0];};
  }).call(MatchingBraceOutdent.prototype);
exports.MatchingBraceOutdent = MatchingBraceOutdent;
});

define("ace/mode/doc_comment_highlight_rules",["require","exports","module","ace/lib/oop","ace/mode/text_highlight_rules"], function(require, exports, module) {
"use strict";

var oop = require("../lib/oop");
var TextHighlightRules = require("./text_highlight_rules").TextHighlightRules;

var DocCommentHighlightRules = function() {
    this.$rules = {
        "start" : [ {
            token : "comment.doc.tag",
            regex : "@[\\w\\d_]+"
        }, 
        DocCommentHighlightRules.getTagRule(),
        {
            defaultToken : "comment.doc",
            caseInsensitive: true
        }]
    };
};

oop.inherits(DocCommentHighlightRules, TextHighlightRules);

DocCommentHighlightRules.getTagRule = function(start) {
    return {
        token : "comment.doc.tag.storage.type",
        regex : "\\b(?:TODO|FIXME|XXX|HACK)\\b"
    };
}

DocCommentHighlightRules.getStartRule = function(start) {
    return {
        token : "comment.doc", // doc comment
        regex : "\\/\\*(?=\\*)",
        next  : start
    };
};

DocCommentHighlightRules.getEndRule = function (start) {
    return {
        token : "comment.doc", // closing comment
        regex : "\\*\\/",
        next  : start
    };
};


exports.DocCommentHighlightRules = DocCommentHighlightRules;

});

define("ace/mode/l42_highlight_rules",["require","exports","module","ace/lib/oop","ace/mode/doc_comment_highlight_rules","ace/mode/text_highlight_rules"], function(require, exports, module) {
"use strict";

var oop = require("../lib/oop");
var DocCommentHighlightRules = require("./doc_comment_highlight_rules").DocCommentHighlightRules;
var TextHighlightRules = require("./text_highlight_rules").TextHighlightRules;

var L42HighlightRules = function() {
    var keywords =
        "refine|method|interface|reuse|return|error|exception|in|if|while|for|whoops|catch|class|imm|fwd|mut|lent|read|capsule|var|loop|else|void";

    var keywordMapper = this.createKeywordMapper({
        "keyword": keywords,
    }, "identifier");

    this.$rules = {
        "start" : [
            {
                token : "comment",
                regex : "\\/\\/.*$"
            },
            DocCommentHighlightRules.getStartRule("doc-start"),
            {
                token : "comment", // multi line comment
                regex : "\\/\\*",
                next : "comment"
            }, {
                token : "comment", // multi line comment
                regex : "\\/\\*",
                next : "comment"
            }, { // Multiline String
                token : 'string', // Start
                regex : '"""%*$',
                push : [
                    {
                        token: 'string',
                        regex:/^(\s*('|\||#|\*).*)/ // middle
                    },{
                        token: 'string',
                        regex:/^\s*"""/, // end
                        caseInsensitive:true,
                        next:"pop"
                    },
                    {defaultToken:"errorHighlight"} // Everything else that does not match
                ]
            }, {
                token : function(val) {
                    return [{
                        type: "errorHighlight",
                        value: "\t"
                        }];
                },                
                regex : /[\t]/ // Replace all tabs with a highlighted tab
            }, {
                token : "string", // single line
                regex : /".*?"/ //'["](?:(?:\\\\.)|(?:[^"\\\\]))*?["]'
            }, {
		        token : function(val) {
                    var numberPattern = /^[-0-9][0-9.]*/;
                    var nums=val.match( numberPattern )
                    if (nums==null){return [{
                        type: "upperIdentifiers",
                        value: val
                        }]}
                    var size=nums[0].length
                    return [{
                        type: "string",
                        value: val.slice(0, size)
                        }, {
                        type: "upperIdentifiers",
                        value: val.slice(size)
                        }];

                },                
                regex : /[-0-9.]*[_]*[A-Z$][a-zA-Z0-9_$]*/ // Classes / Upper Identifiers
            }, {
                token : function(val) {
                    return [{
                            type: "objectCall",
                            value: val.slice(0, -1)
                        }, {
                            type: "text",
                            value: val.slice(-1)
                        }];
                },
                regex : "[.]??[_]*[a-z#][a-zA-Z0-9_$#]*[::[0-9]*]??[\\(|\\[]" // .methodName(
            }, {
                token : function(val) {
                    return [{
                            type: "text",
                            value: val.slice(0,1)
                        }, {
                            type: "errorHighlight",
                            value: val.slice(1)
                        }];
                },
                regex : "[.][a-z_$][a-zA-Z0-9_$]*" // .Field // ERROR
            },{
                token : function(val) {
                    return [{
                            type: "methodParameters",
                            value: val.slice(0, -1)
                        }, {
                            type: "text",
                            value: val.slice(-1)
                        }];
                },
                regex : "[a-z_$][a-zA-Z0-9_$]*\\=(?!=|\\>)" // parameter:
            }, {
                token : function(val) {
                    return [{
                            type: "keyword",
                            value: val.slice(0, "reuse".length)
                        }, {
                            type: "reuselibrary",
                            value: val.slice("reuse".length)
                        }];
                },
                regex : "reuse\\s{1,}[^\{\}\\s]*" // resuse l42.is/AdamTowel
            }, {
                token : keywordMapper,
                regex : "[a-zA-Z_$][a-zA-Z0-9_$]*\\b"
            }, {
                token : "text",
                regex : "!|%|&|\\*|\\-\\-|\\-|\\+\\+|\\+|==|=|:=|!=|<=|>=|<|>|&&|[\\/]|\\*=|%=|\\+=|\\-=|&="
            }
        ],
        "comment" : [
            {
                token : "comment", // closing comment
                regex : ".*?\\*\\/",
                next : "start"
            }, {
                token : "comment", // comment spanning whole line
                regex : ".+"
            }
        ]
    }; this.normalizeRules();

    this.embedRules(DocCommentHighlightRules, "doc-",
        [ DocCommentHighlightRules.getEndRule("start") ]);
};

oop.inherits(L42HighlightRules, TextHighlightRules);

exports.L42HighlightRules = L42HighlightRules;
});

define("ace/mode/folding/cstyle",["require","exports","module","ace/lib/oop","ace/range","ace/mode/folding/fold_mode"], function(require, exports, module) {
"use strict";

var oop = require("../../lib/oop");
var Range = require("../../range").Range;
var BaseFoldMode = require("./fold_mode").FoldMode;

var FoldMode = exports.FoldMode = function(commentRegex) {
    if (commentRegex) {
        this.foldingStartMarker = new RegExp(
            this.foldingStartMarker.source.replace(/\|[^|]*?$/, "|" + commentRegex.start)
        );
        this.foldingStopMarker = new RegExp(
            this.foldingStopMarker.source.replace(/\|[^|]*?$/, "|" + commentRegex.end)
        );
    }
};
oop.inherits(FoldMode, BaseFoldMode);

(function() {
    
    this.foldingStartMarker = /(\{|\[)[^\}\]]*$|^\s*(\/\*)/;
    this.foldingStopMarker = /^[^\[\{]*(\}|\])|^[\s\*]*(\*\/)/;
    this.singleLineBlockCommentRe= /^\s*(\/\*).*\*\/\s*$/;
    this.tripleStarBlockCommentRe = /^\s*(\/\*\*\*).*\*\/\s*$/;
    this.startRegionRe = /^\s*(\/\*|\/\/)#?region\b/;
    this._getFoldWidgetBase = this.getFoldWidget;
    this.getFoldWidget = function(session, foldStyle, row) {
        var line = session.getLine(row);
    
        if (this.singleLineBlockCommentRe.test(line)) {
            if (!this.startRegionRe.test(line) && !this.tripleStarBlockCommentRe.test(line))
                return "";
        }
    
        var fw = this._getFoldWidgetBase(session, foldStyle, row);
    
        if (!fw && this.startRegionRe.test(line))
            return "start"; // lineCommentRegionStart
    
        return fw;
    };

    this.getFoldWidgetRange = function(session, foldStyle, row, forceMultiline) {
        var line = session.getLine(row);
        
        if (this.startRegionRe.test(line))
            return this.getCommentRegionBlock(session, line, row);
        
        var match = line.match(this.foldingStartMarker);
        if (match) {
            var i = match.index;

            if (match[1])
                return this.openingBracketBlock(session, match[1], row, i);
                
            var range = session.getCommentFoldRange(row, i + match[0].length, 1);
            
            if (range && !range.isMultiLine()) {
                if (forceMultiline) {
                    range = this.getSectionRange(session, row);
                } else if (foldStyle != "all")
                    range = null;
            }
            
            return range;
        }

        if (foldStyle === "markbegin")
            return;

        var match = line.match(this.foldingStopMarker);
        if (match) {
            var i = match.index + match[0].length;

            if (match[1])
                return this.closingBracketBlock(session, match[1], row, i);

            return session.getCommentFoldRange(row, i, -1);
        }
    };
    
    this.getSectionRange = function(session, row) {
        var line = session.getLine(row);
        var startIndent = line.search(/\S/);
        var startRow = row;
        var startColumn = line.length;
        row = row + 1;
        var endRow = row;
        var maxRow = session.getLength();
        while (++row < maxRow) {
            line = session.getLine(row);
            var indent = line.search(/\S/);
            if (indent === -1)
                continue;
            if  (startIndent > indent)
                break;
            var subRange = this.getFoldWidgetRange(session, "all", row);
            
            if (subRange) {
                if (subRange.start.row <= startRow) {
                    break;
                } else if (subRange.isMultiLine()) {
                    row = subRange.end.row;
                } else if (startIndent == indent) {
                    break;
                }
            }
            endRow = row;
        }
        
        return new Range(startRow, startColumn, endRow, session.getLine(endRow).length);
    };
    this.getCommentRegionBlock = function(session, line, row) {
        var startColumn = line.search(/\s*$/);
        var maxRow = session.getLength();
        var startRow = row;
        
        var re = /^\s*(?:\/\*|\/\/|--)#?(end)?region\b/;
        var depth = 1;
        while (++row < maxRow) {
            line = session.getLine(row);
            var m = re.exec(line);
            if (!m) continue;
            if (m[1]) depth--;
            else depth++;

            if (!depth) break;
        }

        var endRow = row;
        if (endRow > startRow) {
            return new Range(startRow, startColumn, endRow, line.length);
        }
    };

}).call(FoldMode.prototype);

});

define("ace/mode/l42",["require","exports","module","ace/lib/oop","ace/mode/text","ace/mode/matching_brace_outdent","ace/mode/l42_highlight_rules","ace/mode/folding/cstyle"], function(require, exports, module) {
"use strict";

var oop = require("../lib/oop");
var TextMode = require("./text").Mode;
var MatchingBraceOutdent = require("./matching_brace_outdent").MatchingBraceOutdent;
var MyNewHighlightRules = require("./l42_highlight_rules").L42HighlightRules;
var CStyleFoldMode = require("./folding/cstyle").FoldMode;

var Mode = function() {
    this.HighlightRules = MyNewHighlightRules;
    this.$outdent = new MatchingBraceOutdent();
    this.foldingRules = new CStyleFoldMode();
};
oop.inherits(Mode, TextMode);

(function() {
    this.lineCommentStart = "//";
    this.blockComment = {start: "/*", end: "*/"};
    this.getNextLineIndent = function(state, line, tab) {
        var indent = this.$getIndent(line);
        return indent;
    };

    this.checkOutdent = function(state, line, input) {
        return this.$outdent.checkOutdent(line, input);
    };

    this.autoOutdent = function(state, doc, row) {
        this.$outdent.autoOutdent(doc, row);
    };
    this.createWorker = function(session) {
        return null;
    };
    
}).call(Mode.prototype);

exports.Mode = Mode;
});
