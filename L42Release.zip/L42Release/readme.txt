#How to run
//You need a java14 JDK (the java inside a JRE does not work since it does not have the embedded javac)
java --enable-preview -jar L42_0_001.jar

When the 42 IDE opens, select the folder SifoPluggableTypeSystem (42 projects are folders, not files, so just select the folder)
Press Run
The first run is going to take a longer time because 42 is going to generate local caches for the L42 standard library.
-----
Content of EsopSifo.zip
# L42_0_001.jar: An executable jar including an IDE that implements L42
# localhost: a set of L42 libraries including the SIFO library.
    The jar can be executed with: java --enable-preview -jar L42_0_001.jar
# SifoPluggableTypeSystem
    a folder containg a 42 project where the sifo type system is explored.

When the IDE opens, the project SifoExamples can be loaded with the opened explorer. By clicking Run! at the upper right corner the code is executed. 
In SifoPluggableTypeSystem, four cases studies are implemented:
1 The DatabaseExample is a system where two databases are not allowed to interfere.
    Through the different security levels of the databases, it is ensured that a value read from one database cannot be inserted into the other one. 
2 The EmailExample ensures that encrypted emails are only decrypted if the used public and private key pair is valid.
    It also guarantees that private keys are not leaked.
3/4 BankExample and PaycardExample are two systems that represent payment systems where it is crucial that the calculations of new balances are correct
    and information is not leaked. By labeling the balance with @Top and checking that the system is typable, we are certain that the balance is 
    not leaked to attackers.

Basic Syntax:

If a security level is not specified, the lowest security level is used. If a type modifier is not specified, imm is used.

Example class declaration:
Person={
  Size age //age is a field: 32 bit int, immutable and low
  @Top S password//password is a field: a string immutable and top security
  class method This(Size age, @Top S password) //the constructor
  }
Example Sifo usage

Sifo=Load:{reuse[Sifo]} //loading the Sifo library

SifoTest={
  Left=Sifo:{}  //Left and Right are security levels extending Low
  Right=Sifo:{}
  Top=Sifo:{[Left,Right]} //Top is a security level extending Left and Right
  DeclassifyS=Sifo.declassify(S top=Top) //We allows to declassify immutable
  DatabaseExample=Sifo(Top):{...} //we check the code inside the file called DatabaseExample is correct with respect to
  //Sifo, considering Top as the top level of the securirity lattice